from FalconEye import Flatten
Flatten({}).items